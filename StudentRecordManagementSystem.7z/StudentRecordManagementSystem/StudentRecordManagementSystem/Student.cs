﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Odbc;


namespace StudentRecordManagementSystem
{


    public partial class frmStudent : Form
    {

        public static string firstName = "";
        public static string lastName = "";
        public static string address = "";
        public static string course = "";

        public OdbcConnection connection = new OdbcConnection("DSN=stud;MultipleActiveResultSets=True;");

        public frmStudent()
        {
            InitializeComponent();
        }
      
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtStudentID.Text = "";
            txtLName.Text = "";
            txtFname.Text = "";
            txtAddress.Text = "";

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            frmStudent.ActiveForm.Close();
        }



        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtStudentID.Text == "" && txtFname.Text == "" && txtLName.Text == "" && txtAddress.Text == "")
            {

                MessageBox.Show("All Fields are required", "Information", MessageBoxButtons.OK);
            }
            else
            {
                if (cmbGender.Text != "-Select Gender-" && cmbCourse.Text != "-Select Course-")
                {

                    string courseid = cmbCourse.SelectedValue.ToString();
                    string gender = cmbGender.SelectedItem.ToString();
                    DialogResult Message;
                    string savequery = "";
                    Message = MessageBox.Show("Are you sure to save data into database?", "Informations", MessageBoxButtons.YesNo);
                    if (Message == DialogResult.No)
                    {
                        return;
                    }
                    else // SAVE DATA
                    {
                        savequery = "INSERT INTO tblstudent(studid,fname,lname,address,gender,courseid)VALUES('" + txtStudentID.Text + "','" + txtFname.Text + "','" + txtLName.Text + "','" + txtAddress.Text + "','" + gender + "','" + courseid + "')";

                        //calling function to execute query
                        UpdateData(savequery);

                        connection.Close();

                        // load datagridview with new data
                        LoadData();

                    }
                }
                else
                {
                    MessageBox.Show("All Fields are required", "Information", MessageBoxButtons.OK);
                }
                }
  }


        //main function to insert, update and delete data
        private void UpdateData(string sql)
        {
            try
            {

                // we will using OdbC command
                OdbcCommand cmd = new OdbcCommand();

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = sql;
                cmd.Connection = connection;

                // open connection
                connection.Open();

                // execute
                cmd.ExecuteNonQuery();

                // show message if update data is success
                MessageBox.Show("Command executed sucessfully!", "Informations");

                //function to clear all text boxes
                clear();

                btnSave.Enabled = true;
                connection.Close();
                cmd.Dispose();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }//end 

        private void btnNew_Click(object sender, EventArgs e)
        {
            if (btnNew.Text == "New")
            {
                txtFname.Enabled = true;
                txtLName.Enabled = true;
                txtStudentID.Enabled = true;
                txtAddress.Enabled = true;
                cmbCourse.Enabled = true;
                cmbGender.Enabled = true;
                btnNew.Text = "Back";
                btnSave.Enabled = true;
            }
            else
            {
                disabledTextFields();
            }

        }

        private void LoadData()
        {

            //open our connection
            connection.Open();
           
            // query using dataadapter into our database
            OdbcDataAdapter da = new OdbcDataAdapter("SELECT tblstudent.id ,tblstudent.studid,tblstudent.fname,tblstudent.lname,tblstudent.address,tblstudent.gender,tblcourse.description FROM tblstudent,tblcourse where tblstudent.courseid = tblcourse.id", connection);
            
            // we will using datatable to bing data into datagridview
            DataTable dt = new DataTable();
            da.Fill(dt);
            // bind data into gridview
            dtStudent.DataSource = dt;

            // close connections
            connection.Close();
            da.Dispose();
            dt.Dispose();

        }

        private void clear()
        {
            txtFname.Text = "";
            txtLName.Text = "";
            txtStudentID.Text = "";
            txtAddress.Text = "";
            cmbCourse.Text = "-Select Course-";
            cmbGender.Text = "-Select Gender-";
            txtId.Text = "";

        }

        
        private void disabledTextFields()
        {
            txtFname.Enabled = false;
            txtLName.Enabled = false;
            txtStudentID.Enabled = false;
            txtAddress.Enabled = false;
            cmbCourse.Enabled = false;
            cmbGender.Enabled = false;
            btnNew.Text = "New";
            btnSave.Enabled = false;
        }

        //function to autoresize column widt according to data
        private void dataGridColumn()
        {
            // Resize the master DataGridView columns to fit the newly loaded data.
            dtStudent.AutoResizeColumns();

            // Configure the details DataGridView so that its columns automatically
            // adjust their widths when the data changes.
            dtStudent.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.AllCells;
        }



        private void btnUpdate_Click(object sender, EventArgs e)
        {

            if (txtStudentID.Text == "" && txtFname.Text == "" && txtLName.Text == "" && txtAddress.Text == "" )
            {

                MessageBox.Show("Select student to update", "Information", MessageBoxButtons.OK);
                return;
            }
            else
            {

                DialogResult message = MessageBox.Show("Are you sure to update data into database?", "Informations", MessageBoxButtons.YesNo);
                if (message == DialogResult.No)
                {
                    return;
                }
                else
                {
                    if (cmbCourse.SelectedValue.ToString() == null && cmbGender.SelectedItem.ToString() == null)
                    {

                        MessageBox.Show("Select Gender and Course", "Informations", MessageBoxButtons.OK);
                        
                    }
                    else
                    {
                        string courseid = cmbCourse.SelectedValue.ToString();
                        string gender = cmbGender.SelectedItem.ToString();
                        string studid = txtStudentID.Text;
                        string fname = txtFname.Text;
                        string lname = txtLName.Text;
                        string address = txtAddress.Text;

                        string updatequery = "UPDATE tblstudent set fname='" + fname + "',lname='" + lname + "',address='" + address + "',gender='" + gender + "',courseid='" + courseid + "',studid='" + studid + "' where id=" + txtId.Text + "";
                        // call functions to update or insert new data
                        UpdateData(updatequery);

                        //disable button update and delete
                        btnUpdate.Enabled = false;
                        btnDelete.Enabled = false;


                        connection.Close();
                        // load datagridview with new data
                        LoadData();
                    }
                   
                }
            }
        }

        private void frmStudent_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSetCourse.tblcourse' table. You can move, or remove it, as needed.
            this.tblcourseTableAdapter.Fill(this.dataSetCourse.tblcourse);

            //fetch students data from database
            LoadData();


            disabledTextFields();

            //auto resize dataGridColumn 
            dataGridColumn();
        }

        private void dtStudent_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                // value from datagrid where clicked cells is the same in the textbox
                DataGridViewRow rows = dtStudent.Rows[e.RowIndex];
                txtId.Text = rows.Cells[0].Value.ToString();
                txtStudentID.Text = rows.Cells[1].Value.ToString();
                txtFname.Text = rows.Cells[2].Value.ToString();
                txtLName.Text = rows.Cells[3].Value.ToString();
                txtAddress.Text = rows.Cells[4].Value.ToString();
                cmbGender.Text = rows.Cells[5].Value.ToString();
                cmbCourse.Text = rows.Cells[6].Value.ToString();

                //enable text boxes for editing and deleting
                txtStudentID.Enabled = true;
                txtFname.Enabled = true;
                txtLName.Enabled = true;
                cmbGender.Enabled = true;
                txtAddress.Enabled = true;
                cmbCourse.Enabled = true;

                //enable btn Delete and update
                btnDelete.Enabled = true;
                btnUpdate.Enabled = true;

                //disable btn save
                btnSave.Enabled = false;
            }
            catch
            {
                return;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtStudentID.Text == "" && txtFname.Text == "" && txtLName.Text == "" && txtAddress.Text == "")
                {
                    MessageBox.Show("Select item to Delete", "Warning", MessageBoxButtons.OK);
                    return;
                }
                else
                {
                    DialogResult Message;
                    string delete = "";
                    Message = MessageBox.Show("Are you sure to delete this data? All of the records related to student will be permanently deleted", "Proceed with caution", MessageBoxButtons.YesNo);
                    if (Message == DialogResult.No)
                    {
                        // if users click "NO" dialog, will exit the method and do nothing
                        return;
                    }
                    else
                    {
                        int id = int.Parse(txtId.Text);
                        // else, we will delete all data from selected id in TextBox1
                        delete = "DELETE from tblstudent WHERE id=" + id + "";
                        // call functions update data to execute the string query
                        UpdateData(delete);
                        LoadData();

                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Cannot perform deletion of a course because data is referenced to student table", "Danger", MessageBoxButtons.OK);
                return;

            }
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            if (txtStudentID.Text == "" && txtFname.Text == "" && txtLName.Text == "" && txtAddress.Text == "")
            {
                MessageBox.Show("Select item to view", "Warning", MessageBoxButtons.OK);
                return;
            }
            else
            {
                firstName = txtFname.Text;
                lastName = txtLName.Text;
                address = txtAddress.Text;
                course = cmbCourse.Text;
            }
            
            PrintStudent pst = new PrintStudent();
            pst.Show();
        }

        private void btnView_Click_1(object sender, EventArgs e)
        {
            if(txtFname.Text == "" && txtLName.Text == "" && txtStudentID.Text == "")
            {
                MessageBox.Show("Select item to view", "Information", MessageBoxButtons.OK);
                return;
            }else
            {
                //pass data to public variables
                firstName = txtFname.Text;
                lastName = txtLName.Text;
                address = txtAddress.Text;
                course = cmbCourse.Text;

                PrintStudent psd = new PrintStudent();
                psd.Show();
            }
        }
    }
}
