﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Odbc;

namespace StudentRecordManagementSystem
{
    public partial class frmSubject : Form
    {
        public frmSubject()
        {
            InitializeComponent();
        }

        public OdbcConnection connection = new OdbcConnection("DSN=java_db;MultipleActiveResultSets=True;");
        // declaration for NewData
        public Boolean NewData;

        private void btnSave_Click(object sender, EventArgs e)
        {
            
        }
    }
}
