﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.Odbc;


namespace StudentRecordManagementSystem
{
   
    public partial class frmCourse : Form
    {
        public static string id;

        public OdbcConnection connection = new OdbcConnection("DSN=stud;MultipleActiveResultSets=True;");
        // declaration for NewData
        public frmCourse()
        {
            InitializeComponent();
        }
        // its for our connection
       
        private void frmCourse_Load(object sender, EventArgs e)
        {
            // declaration for newdata is true
            // if newData is true, we will Insert new data to database
            // if newdata is false, so we will Update data into database while data is existing
            LoadData();
            txtId.Enabled = false;
            txtCourseCode.Enabled = false;
            txtCourseDescription.Enabled = false;

            //disabled buttons
            btnSave.Enabled = false;
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;

            //call function autoresize when form loaded
            dataGridColumn();



        }

        private void LoadData()
        {
            // create connection before
            //open our connection
            connection.Open();
            // query using dataadapter into our database
            OdbcDataAdapter da = new OdbcDataAdapter("SELECT * FROM tblcourse order by id", connection);
            // we will using datatable to bing data into datagridview
            DataTable dt = new DataTable();
            da.Fill(dt);
            // bind data into gridview
            dataGridView1.DataSource = dt;


            //call function autoresize when form loaded
            dataGridColumn();

            // close connections
            connection.Close();
            da.Dispose();
            dt.Dispose();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            if (btnNew.Text == "New")
            {
                txtCourseCode.Enabled = true;
                txtCourseDescription.Enabled = true;
                btnNew.Text = "Back";

                //enable button save and disable btn delete and update
                btnSave.Enabled = true;
                btnUpdate.Enabled = false;
                btnDelete.Enabled = false;
            }
            else
            {
                txtCourseCode.Enabled = false;
                txtCourseDescription.Enabled = false;
                btnNew.Text = "New";
                btnSave.Enabled = false;
            }


        }

        //main function to insert,update and delete data
        private void UpdateData(string sql)
        {
            try
            {
              
                // we will using OdbC command
                OdbcCommand cmd = new OdbcCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = sql;
                cmd.Connection = connection;

                // open connection
                connection.Open();

                // execute
                cmd.ExecuteNonQuery();
      
                // show message if update data is success
                    MessageBox.Show("command success!", "Informations");
                clear();
                connection.Close();
                cmd.Dispose();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }//end 

        private void btnSave_Click(object sender, EventArgs e)
        {

            if (txtCourseCode.Text != "" && txtCourseDescription.Text != "")
            {
                DialogResult Message;
                string myquery = "";


                    Message = MessageBox.Show("Are you sure to save data into database?", "Informations", MessageBoxButtons.YesNo);
                    if (Message == DialogResult.No)
                    {
                        return;
                    } // SAVE DATA
                    myquery = "INSERT INTO tblcourse(coursecode,description)VALUES('" + txtCourseCode.Text + "','" + txtCourseDescription.Text + "')";
                
                               
                // call functions to insert new data
                UpdateData(myquery);

                // load datagridview with new data
                connection.Close();
                LoadData();
            }
            else {
                MessageBox.Show("CourseID and Description is required", "Warning", MessageBoxButtons.OK);

            }
        }//end of btnsave

        private void btnClear_Click(object sender, EventArgs e)
        {
           clear();

        }//end

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void clear() {
            txtCourseCode.Text = "";
            txtCourseDescription.Text = "";
            txtId.Text = "";

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                // value from datagrid where clicked cells is same in the textbox
                DataGridViewRow rows = dataGridView1.Rows[e.RowIndex];
                txtId.Text = rows.Cells[0].Value.ToString();
                txtCourseCode.Text = rows.Cells[1].Value.ToString();
                txtCourseDescription.Text = rows.Cells[2].Value.ToString();

                //enable text boxes for editing and deleting
                txtCourseCode.Enabled = true;
                txtCourseDescription.Enabled = true;

                //enable btn Delete and update
                btnDelete.Enabled = true;
                btnUpdate.Enabled = true;

                //disable btn save
                btnSave.Enabled = false;
            }
            catch
            {
                return;
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtCourseCode.Text == "" && txtCourseDescription.Text == "")
            {
                MessageBox.Show("Select course to update", "Warning", MessageBoxButtons.OK);
                
            }
            else
            {
                DialogResult Message = MessageBox.Show("Are you sure to update data into database?", "Informations", MessageBoxButtons.YesNo);
                if (Message == DialogResult.No)
                {
                    return;
                }
                else
                {

                   
                    int id = int.Parse(txtId.Text);
                    String coursecode = txtCourseCode.Text;
                    String description = txtCourseDescription.Text;
                    string myquery = "UPDATE tblcourse set coursecode='" + coursecode + "',description='" + description + "' where id=" + id + "";

                    // call functions to update or insert new data
                    UpdateData(myquery);

                    // close database connection
                    connection.Close();

                    //load data to datagrid
                    LoadData();

                    //disable txtboxes
                    txtCourseDescription.Enabled = false;
                    txtCourseCode.Enabled = false;

                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtCourseCode.Text == "" && txtCourseDescription.Text == "")
                {
                    MessageBox.Show("Select item to Delete", "Warning", MessageBoxButtons.OK);
                }
                else
                {
                    DialogResult Message;
                    string delete = "";
                    Message = MessageBox.Show("Are you sure to delete this data?", "Warning", MessageBoxButtons.YesNo);
                    if (Message == DialogResult.No)
                    {
                        // if users click "NO" dialog, will exit the method and do nothing
                        return;
                    }
                    else
                    {
                        int id = int.Parse(txtId.Text);
                        // else, we will delete all data from selected id in TextBox1
                        delete = "DELETE from tblcourse WHERE id=" + id + "";
                        // call functions update data to execute the string query
                        UpdateData(delete);
                        LoadData();

                    }
                }
            }
            catch(Exception) {
                MessageBox.Show("Cannot perform deletion of a course because data is referenced to student table","Danger",MessageBoxButtons.OK);
                return;

            }
        }

        //function to autoresize column width 
        private void dataGridColumn()
        {
            // Resize the master DataGridView columns to fit the newly loaded data.
            dataGridView1.AutoResizeColumns();

            // Configure the details DataGridView so that its columns automatically
            // adjust their widths when the data changes.
            dataGridView1.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.AllCells;
        }
    }
}
