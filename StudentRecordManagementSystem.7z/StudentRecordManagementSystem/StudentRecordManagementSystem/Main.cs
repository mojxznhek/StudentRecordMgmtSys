﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentRecordManagementSystem
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }



      
        private void btnCourse_Click(object sender, EventArgs e)
        {
            frmCourse cs = new frmCourse();
            cs.ShowDialog();
        }

        private void btnStudent_Click(object sender, EventArgs e)
        {
           frmStudent st = new frmStudent();
            st.ShowDialog();
        }

    }
}
